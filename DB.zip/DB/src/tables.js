export const tables = {
    users: 'vartotojai',
    faq: 'duk',
    developers: 'kurejai',
    orders: 'uzsakymai',
    games: 'zaidimai',
    payments: 'mokejimai',
    groups: 'grupes',
    reviews: 'atsiliepimai',
    images: 'nuotraukos',
    carts: 'krepseliai'
};